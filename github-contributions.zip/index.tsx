import {
  Button,
  HStack,
  Image,
  List,
  Navigation,
  NavigationStack,
  Picker,
  Section,
  SecureField,
  Spacer,
  Text,
  TextField,
  VStack,
  Widget,
  fetch,
  useMemo,
  useState
} from 'scripting'

import {
  DEFAULT_WIDGET_CONFIG,
  GithubContributionsData,
  GithubProfile,
  STORAGE_KEYS,
  TEST_CONTRIBUTIONS,
  WidgetConfig,
  formatUpdatedAt
} from './model'

function hasStorage(): boolean {
  return typeof Storage !== 'undefined' && Storage != null
}

function loadProfile(): GithubProfile {
  if (!hasStorage()) {
    return { username: TEST_CONTRIBUTIONS.username, token: '' }
  }
  try {
    return (Storage.get(STORAGE_KEYS.PROFILE) as GithubProfile | null) || {
      username: '',
      token: ''
    }
  } catch (e) {
    console.log('loadProfile error', e)
    return { username: '', token: '' }
  }
}

function saveProfile(profile: GithubProfile) {
  if (!hasStorage()) return
  Storage.set(STORAGE_KEYS.PROFILE, profile)
}

function loadWidgetConfig(): WidgetConfig {
  if (!hasStorage()) {
    return DEFAULT_WIDGET_CONFIG
  }
  try {
    return (Storage.get(STORAGE_KEYS.WIDGET_CONFIG) as WidgetConfig | null) || DEFAULT_WIDGET_CONFIG
  } catch (e) {
    console.log('loadWidgetConfig error', e)
    return DEFAULT_WIDGET_CONFIG
  }
}

function saveWidgetConfig(config: WidgetConfig) {
  if (!hasStorage()) return
  Storage.set(STORAGE_KEYS.WIDGET_CONFIG, config)
}

function loadCache(): GithubContributionsData | null {
  if (!hasStorage()) {
    return TEST_CONTRIBUTIONS
  }
  try {
    return (Storage.get(STORAGE_KEYS.CONTRIBUTIONS_CACHE) as GithubContributionsData | null) || null
  } catch (e) {
    console.log('loadCache error', e)
    return null
  }
}

function saveCache(data: GithubContributionsData) {
  if (!hasStorage()) return
  Storage.set(STORAGE_KEYS.CONTRIBUTIONS_CACHE, data)
}

function reloadWidgets() {
  try {
    Widget.reloadAll()
  } catch (e) {
    console.log('reloadWidgets error', e)
  }
}

function padDate(date: Date) {
  return date.toISOString()
}

function mapContributionLevel(level: string): 0 | 1 | 2 | 3 | 4 {
  if (level === 'FOURTH_QUARTILE') return 4
  if (level === 'THIRD_QUARTILE') return 3
  if (level === 'SECOND_QUARTILE') return 2
  if (level === 'FIRST_QUARTILE') return 1
  return 0
}

function ensure140Days(days: GithubContributionsData['days']) {
  const map = new Map(days.map(day => [day.date, day]))
  const today = new Date()
  const normalized: GithubContributionsData['days'] = []

  for (let i = 139; i >= 0; i--) {
    const date = new Date(today)
    date.setHours(0, 0, 0, 0)
    date.setDate(date.getDate() - i)
    const key = date.toISOString().slice(0, 10)
    const found = map.get(key)

    normalized.push(
      found || {
        date: key,
        count: 0,
        level: 0
      }
    )
  }

  return normalized
}

async function fetchGithubContributions(token?: string): Promise<GithubContributionsData> {
  const authToken = token?.trim()

  if (!authToken) {
    throw new Error('请先配置 GitHub Personal Access Token，用于查询和更新贡献数据')
  }

  const viewerResponse = await fetch('https://api.github.com/user', {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${authToken}`,
      Accept: 'application/vnd.github+json',
      'User-Agent': 'Scripting-GitHub-Contributions-Widget'
    },
    timeout: 20,
    debugLabel: 'github-user-index'
  })

  if (!viewerResponse.ok) {
    const message = await viewerResponse.text().catch(() => '')
    throw new Error(`GitHub User API ${viewerResponse.status}: ${message || viewerResponse.statusText}`)
  }

  const viewerJson = await viewerResponse.json()
  const login = String(viewerJson?.login || '').trim()

  if (!login) {
    throw new Error('无法通过 token 获取当前 GitHub 用户，请检查 token 是否有效')
  }

  const from = new Date()
  from.setHours(0, 0, 0, 0)
  from.setDate(from.getDate() - 139)

  const to = new Date()
  to.setHours(23, 59, 59, 999)

  const query = `
    query($login: String!, $from: DateTime!, $to: DateTime!) {
      user(login: $login) {
        contributionsCollection(from: $from, to: $to) {
          contributionCalendar {
            totalContributions
            weeks {
              contributionDays {
                contributionCount
                contributionLevel
                date
              }
            }
          }
        }
      }
    }
  `

  const response = await fetch('https://api.github.com/graphql', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${authToken}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
      'User-Agent': 'Scripting-GitHub-Contributions-Widget'
    },
    body: JSON.stringify({
      query,
      variables: {
        login,
        from: padDate(from),
        to: padDate(to)
      }
    }),
    timeout: 20,
    debugLabel: 'github-graphql-contributions-index'
  })

  if (!response.ok) {
    const message = await response.text().catch(() => '')
    throw new Error(`GitHub GraphQL ${response.status}: ${message || response.statusText}`)
  }

  const json = await response.json()

  if (Array.isArray(json?.errors) && json.errors.length > 0) {
    const message = json.errors.map((item: any) => item?.message || 'Unknown error').join('; ')
    throw new Error(message)
  }

  const calendar = json?.data?.user?.contributionsCollection?.contributionCalendar

  if (!calendar) {
    throw new Error('未获取到 contribution calendar，请检查 token 权限')
  }

  const rawDays = (calendar.weeks || [])
    .flatMap((week: any) => week?.contributionDays || [])
    .map((day: any) => ({
      date: String(day.date).slice(0, 10),
      count: Number(day.contributionCount || 0),
      level: mapContributionLevel(String(day.contributionLevel || 'NONE'))
    }))

  const days = ensure140Days(rawDays)

  return {
    username: login,
    total: Number(calendar.totalContributions || days.reduce((sum, day) => sum + day.count, 0)),
    days,
    lastUpdate: Date.now()
  }
}

function SummaryCard({ data }: { data: GithubContributionsData | null }) {
  if (!data) {
    return (
      <VStack padding={16} spacing={8} frame={{ maxWidth: 'infinity' }}>
        <Image systemName="square.grid.3x3.fill" font="title" foregroundStyle="secondaryLabel" />
        <Text foregroundStyle="secondaryLabel">还没有数据</Text>
      </VStack>
    )
  }

  const recent = data.days.slice(-28)
  const activeDays = recent.filter(item => item.count > 0).length

  return (
    <VStack
      padding={16}
      spacing={10}
      background="secondarySystemBackground"
      clipShape={{ type: 'rect', cornerRadius: 16 }}
      frame={{ maxWidth: 'infinity' }}
      alignment="leading"
    >
      <HStack frame={{ maxWidth: 'infinity' }}>
        <VStack alignment="leading" spacing={2}>
          <Text font="headline">@{data.username}</Text>
          <Text font="caption" foregroundStyle="secondaryLabel">
            最近 140 天 GitHub 贡献
          </Text>
        </VStack>
        <Spacer />
        <Image systemName="chart.bar.xaxis" foregroundStyle="systemGreen" />
      </HStack>

      <HStack spacing={20}>
        <VStack alignment="leading" spacing={2}>
          <Text font="title2" fontWeight="bold">{String(data.total)}</Text>
          <Text font="caption" foregroundStyle="secondaryLabel">总贡献</Text>
        </VStack>
        <VStack alignment="leading" spacing={2}>
          <Text font="title2" fontWeight="bold">{String(activeDays)}</Text>
          <Text font="caption" foregroundStyle="secondaryLabel">近 28 天活跃日</Text>
        </VStack>
      </HStack>

      <Text font="caption2" foregroundStyle="tertiaryLabel">
        更新于 {formatUpdatedAt(data.lastUpdate)}
      </Text>
    </VStack>
  )
}

function HeatmapPreview({ data }: { data: GithubContributionsData | null }) {
  if (!data) return null

  const days = data.days.slice(-35)
  const rows: typeof days[] = [[], [], [], [], [], [], []]

  days.forEach((day, index) => {
    rows[index % 7].push(day)
  })

  const colors = ['#ebedf0', '#9be9a8', '#40c463', '#30a14e', '#216e39']

  return (
    <VStack spacing={6} alignment="leading">
      <Text font="subheadline" fontWeight="semibold">预览</Text>
      <VStack spacing={4}>
        {rows.map((row, rowIndex) => (
          <HStack key={String(rowIndex)} spacing={4}>
            {row.map(day => (
              <VStack
                key={day.date}
                frame={{ width: 14, height: 14 }}
                background={colors[day.level] as any}
                clipShape={{ type: 'rect', cornerRadius: 3 }}
              />
            ))}
          </HStack>
        ))}
      </VStack>
    </VStack>
  )
}

function SettingsView({
  config,
  onChange
}: {
  config: WidgetConfig
  onChange: (config: WidgetConfig) => void
}) {
  return (
    <List navigationTitle="小组件设置">
      <Section header={<Text>刷新</Text>}>
        <Picker
          title="刷新间隔"
          value={String(config.refreshInterval)}
          onChanged={(v: string) => onChange({ ...config, refreshInterval: parseInt(v) || 60 })}
        >
          <Text tag="30">30 分钟</Text>
          <Text tag="60">1 小时</Text>
          <Text tag="180">3 小时</Text>
          <Text tag="360">6 小时</Text>
        </Picker>
      </Section>

      <Section footer={<Text>保存后会自动刷新小组件。</Text>}>
        <Text foregroundStyle="secondaryLabel">当前账号：{config.username || '未设置'}</Text>
      </Section>
    </List>
  )
}

function App() {
  const [profile, setProfile] = useState<GithubProfile>(() => loadProfile())
  const [widgetConfig, setWidgetConfig] = useState<WidgetConfig>(() => {
    const saved = loadWidgetConfig()
    if (!saved.username && loadProfile().username) {
      return { ...saved, username: loadProfile().username }
    }
    return saved
  })
  const [data, setData] = useState<GithubContributionsData | null>(() => loadCache())
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [errorText, setErrorText] = useState('')
  const [showSettings, setShowSettings] = useState(false)

  const canRefresh = (profile.token || '').trim().length > 0

  const activeDays = useMemo(() => {
    return data?.days.filter(item => item.count > 0).length || 0
  }, [data])

  async function refresh() {
    if (!(profile.token || '').trim()) return
        setIsRefreshing(true)
        setErrorText('')
        try {
          const next = await fetchGithubContributions(profile.token?.trim())
          setData(next)
          saveCache(next)

          const nextProfile = {
            username: next.username,
            token: profile.token?.trim() || ''
          }
          setProfile(nextProfile)
          saveProfile(nextProfile)

          const nextConfig = {
            ...widgetConfig,
            username: next.username,
            token: profile.token?.trim() || ''
          }
          setWidgetConfig(nextConfig)
          saveWidgetConfig(nextConfig)

          reloadWidgets()
        } catch (e: any) {
          console.log('refresh error', e)
          setErrorText(String(e?.message || e))
        } finally {
          setIsRefreshing(false)
        }
  }

  if (showSettings) {
    return (
      <NavigationStack>
        <SettingsView
          config={widgetConfig}
          onChange={(config) => {
            setWidgetConfig(config)
            saveWidgetConfig(config)
            reloadWidgets()
          }}
        />
      </NavigationStack>
    )
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="GitHub Contributions"
        toolbar={{
          topBarLeading: (
            <Button
              title=""
              systemImage="gear"
              action={() => setShowSettings(true)}
            />
          ),
          topBarTrailing: (
            <Button
              title=""
              systemImage={isRefreshing ? 'arrow.triangle.2.circlepath' : 'arrow.clockwise'}
              action={refresh}
              disabled={!canRefresh || isRefreshing}
            />
          )
        }}
      >
        <Section
                  header={<Text>账号</Text>}
                  footer={<Text>仅需填写 GitHub Personal Access Token。程序会自动识别当前 GitHub 账号，并使用该账号查询和更新 contribution calendar 数据。</Text>}
                >
                  <SecureField
                    title="GitHub Personal Access Token"
                    value={profile.token || ''}
                    onChanged={(v) => setProfile({ ...profile, token: v })}
                    prompt="必填"
                  />
                  <Text foregroundStyle="secondaryLabel">
                    当前账号：{data?.username || profile.username || '未识别'}
                  </Text>
                  <Button
                    title={isRefreshing ? '刷新中...' : '保存并刷新'}
                    action={refresh}
                    disabled={!canRefresh || isRefreshing}
                  />
                </Section>

        <Section header={<Text>概览</Text>}>
          <SummaryCard data={data} />
          {data ? (
            <VStack alignment="leading" spacing={4} padding={{ vertical: 4 }}>
              <Text font="caption" foregroundStyle="secondaryLabel">
                活跃天数：{String(activeDays)}
              </Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                数据来源：GitHub GraphQL contributionCalendar
              </Text>
            </VStack>
          ) : null}
        </Section>

        <Section header={<Text>热力图</Text>}>
          <HeatmapPreview data={data} />
        </Section>

        {errorText ? (
          <Section header={<Text>错误</Text>}>
            <Text foregroundStyle="systemRed">{errorText}</Text>
          </Section>
        ) : null}

        <Section>
          <Button
            title="预览小组件"
            action={async () => {
              await Widget.preview({
                family: 'systemSmall'
              })
            }}
          />
        </Section>
      </List>
    </NavigationStack>
  )
}

Navigation.present({
  element: <App />
})