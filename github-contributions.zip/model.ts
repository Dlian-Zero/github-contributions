export interface ContributionDay {
  date: string
  count: number
  level: 0 | 1 | 2 | 3 | 4
}

export interface GithubProfile {
  username: string
  token?: string
}

export interface GithubContributionsData {
  username: string
  total: number
  days: ContributionDay[]
  lastUpdate: number
}

export interface WidgetConfig {
  username: string
  token?: string
  refreshInterval: number
}

export const STORAGE_KEYS = {
  PROFILE: 'github_profile',
  CONTRIBUTIONS_CACHE: 'github_contributions_cache',
  WIDGET_CONFIG: 'github_widget_config'
} as const

export const DEFAULT_WIDGET_CONFIG: WidgetConfig = {
  username: '',
  token: '',
  refreshInterval: 60
}

export const TEST_CONTRIBUTIONS: GithubContributionsData = {
  username: 'octocat',
  total: 642,
  lastUpdate: Date.now(),
  days: Array.from({ length: 140 }).map((_, index) => {
    const seed = index % 11
    const count =
      seed === 0 ? 0 :
      seed <= 3 ? 1 + (index % 2) :
      seed <= 6 ? 3 + (index % 4) :
      seed <= 8 ? 7 + (index % 6) :
      12 + (index % 10)

    const level =
      count === 0 ? 0 :
      count < 2 ? 1 :
      count < 5 ? 2 :
      count < 10 ? 3 : 4

    const date = new Date()
    date.setDate(date.getDate() - (139 - index))

    return {
      date: date.toISOString().slice(0, 10),
      count,
      level: level as 0 | 1 | 2 | 3 | 4
    }
  })
}

export function levelFromCount(count: number): 0 | 1 | 2 | 3 | 4 {
  if (count <= 0) return 0
  if (count < 2) return 1
  if (count < 5) return 2
  if (count < 10) return 3
  return 4
}

export function formatUpdatedAt(timestamp: number): string {
  if (!timestamp) return '--'
  const date = new Date(timestamp)
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  return `${month}-${day} ${hours}:${minutes}`
}

export function getRecentDays(days: ContributionDay[], count: number): ContributionDay[] {
  if (days.length <= count) return days
  return days.slice(days.length - count)
}

export function chunkIntoWeeks(days: ContributionDay[]): ContributionDay[][] {
  const weeks: ContributionDay[][] = []
  for (let i = 0; i < days.length; i += 7) {
    weeks.push(days.slice(i, i + 7))
  }
  return weeks
}