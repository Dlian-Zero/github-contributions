import { EnvironmentValuesReader, HStack, Text, VStack, Widget, fetch } from 'scripting'
import {
  DEFAULT_WIDGET_CONFIG,
  GithubContributionsData,
  STORAGE_KEYS,
  TEST_CONTRIBUTIONS,
  WidgetConfig,
  chunkIntoWeeks,
  getRecentDays
} from './model'

const COLORS = {
  light: {
    background: '#ffffff',
    text: '#24292f',
    subtext: '#6e7781',
    empty: '#ebedf0',
    l1: '#9be9a8',
    l2: '#40c463',
    l3: '#30a14e',
    l4: '#216e39',
    error: '#d1242f'
  },
  dark: {
    background: '#0d1117',
    text: '#e6edf3',
    subtext: '#7d8590',
    empty: '#161b22',
    l1: '#0e4429',
    l2: '#006d32',
    l3: '#26a641',
    l4: '#39d353',
    error: '#f85149'
  }
} as const

function getTheme(colorScheme?: 'light' | 'dark') {
  return COLORS[colorScheme === 'dark' ? 'dark' : 'light']
}

function getWidgetConfig(): WidgetConfig {
  try {
    return (Storage.get(STORAGE_KEYS.WIDGET_CONFIG) as WidgetConfig | null) || DEFAULT_WIDGET_CONFIG
  } catch (error) {
    console.log('load config error', error)
    return DEFAULT_WIDGET_CONFIG
  }
}

function loadCache(): GithubContributionsData | null {
  try {
    return (Storage.get(STORAGE_KEYS.CONTRIBUTIONS_CACHE) as GithubContributionsData | null) || null
  } catch (error) {
    console.log('load cache error', error)
    return null
  }
}

function padDate(date: Date) {
  return date.toISOString()
}

function mapContributionLevel(level: string): 0 | 1 | 2 | 3 | 4 {
  if (level === 'FOURTH_QUARTILE') return 4
  if (level === 'THIRD_QUARTILE') return 3
  if (level === 'SECOND_QUARTILE') return 2
  if (level === 'FIRST_QUARTILE') return 1
  return 0
}

function ensure140Days(days: GithubContributionsData['days']) {
  const map = new Map(days.map(day => [day.date, day]))
  const today = new Date()
  const normalized: GithubContributionsData['days'] = []

  for (let i = 139; i >= 0; i--) {
    const date = new Date(today)
    date.setHours(0, 0, 0, 0)
    date.setDate(date.getDate() - i)
    const key = date.toISOString().slice(0, 10)
    const found = map.get(key)

    normalized.push(
      found || {
        date: key,
        count: 0,
        level: 0
      }
    )
  }

  return normalized
}

async function fetchGitHubContributions(config: WidgetConfig): Promise<GithubContributionsData> {
  const token = config.token?.trim()

  if (!token) {
    if (!config.username?.trim()) {
      return TEST_CONTRIBUTIONS
    }
    throw new Error('请先配置 GitHub Personal Access Token，用于查询和更新贡献数据')
  }

  const viewerResponse = await fetch('https://api.github.com/user', {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
      'User-Agent': 'Scripting-GitHub-Contributions-Widget'
    },
    timeout: 20,
    debugLabel: 'github-user-widget'
  })

  if (!viewerResponse.ok) {
    const message = await viewerResponse.text().catch(() => '')
    throw new Error(`GitHub User API ${viewerResponse.status}: ${message || viewerResponse.statusText}`)
  }

  const viewerJson = await viewerResponse.json()
  const username = String(viewerJson?.login || '').trim()

  if (!username) {
    throw new Error('无法通过 token 获取当前 GitHub 用户，请检查 token 是否有效')
  }

  const from = new Date()
  from.setHours(0, 0, 0, 0)
  from.setDate(from.getDate() - 139)

  const to = new Date()
  to.setHours(23, 59, 59, 999)

  const query = `
    query($login: String!, $from: DateTime!, $to: DateTime!) {
      user(login: $login) {
        contributionsCollection(from: $from, to: $to) {
          contributionCalendar {
            totalContributions
            weeks {
              contributionDays {
                contributionCount
                contributionLevel
                date
              }
            }
          }
        }
      }
    }
  `

  const response = await fetch('https://api.github.com/graphql', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
      'User-Agent': 'Scripting-GitHub-Contributions-Widget'
    },
    body: JSON.stringify({
      query,
      variables: {
        login: username,
        from: padDate(from),
        to: padDate(to)
      }
    }),
    timeout: 20,
    debugLabel: 'github-graphql-contributions-widget'
  })

  if (!response.ok) {
    const message = await response.text().catch(() => '')
    throw new Error(`GitHub GraphQL ${response.status}: ${message || response.statusText}`)
  }

  const json = await response.json()

  if (Array.isArray(json?.errors) && json.errors.length > 0) {
    const message = json.errors.map((item: any) => item?.message || 'Unknown error').join('; ')
    throw new Error(message)
  }

  const calendar = json?.data?.user?.contributionsCollection?.contributionCalendar

  if (!calendar) {
    throw new Error('未获取到 contribution calendar，请检查 token 权限')
  }

  const rawDays = (calendar.weeks || [])
    .flatMap((week: any) => week?.contributionDays || [])
    .map((day: any) => ({
      date: String(day.date).slice(0, 10),
      count: Number(day.contributionCount || 0),
      level: mapContributionLevel(String(day.contributionLevel || 'NONE'))
    }))

  const days = ensure140Days(rawDays)

  return {
    username,
    total: Number(calendar.totalContributions || days.reduce((sum, day) => sum + day.count, 0)),
    days,
    lastUpdate: Date.now()
  }
}

function getLevelColor(
  level: 0 | 1 | 2 | 3 | 4,
  colorScheme?: 'light' | 'dark'
) {
  const theme = getTheme(colorScheme)
  if (level === 0) return theme.empty
  if (level === 1) return theme.l1
  if (level === 2) return theme.l2
  if (level === 3) return theme.l3
  return theme.l4
}

function HeatmapGrid({
  weeks,
  colorScheme
}: {
  weeks: ReturnType<typeof chunkIntoWeeks>
  colorScheme?: 'light' | 'dark'
}) {
  const displaySize = Widget.displaySize
  const weeksCount = weeks.length
  const horizontalSpacing = displaySize.width < 200 ? 2 : displaySize.width < 300 ? 3 : 4
  const verticalSpacing = displaySize.width < 200 ? 2 : 3
  const reservedHeight = displaySize.height < 200 ? 78 : 90
  const cellSize = Math.max(
    6,
    Math.floor(
      Math.min(
        (displaySize.width - 26 - horizontalSpacing * Math.max(0, weeksCount - 1)) / Math.max(1, weeksCount),
        (displaySize.height - reservedHeight - verticalSpacing * 6) / 7
      )
    )
  )

  return (
    <HStack spacing={horizontalSpacing}>
      {weeks.map((week, weekIndex) => (
        <VStack key={String(weekIndex)} spacing={verticalSpacing}>
          {week.map(day => (
            <VStack
              key={day.date}
              frame={{ width: cellSize, height: cellSize }}
              background={getLevelColor(day.level, colorScheme) as any}
              clipShape={{ type: 'rect', cornerRadius: 2 }}
            />
          ))}
        </VStack>
      ))}
    </HStack>
  )
}

function buildWidgetView(
  data: GithubContributionsData,
  colorScheme?: 'light' | 'dark'
) {
  const theme = getTheme(colorScheme)
  const displaySize = Widget.displaySize

  let weeksToShow = 20
  if (displaySize.width < 200) {
    weeksToShow = 12
  } else if (displaySize.width < 300) {
    weeksToShow = 16
  }

  const weeks = chunkIntoWeeks(getRecentDays(data.days, 140))
  const recentWeeks = weeks.slice(-weeksToShow)
  const allDays = weeks.flat()
  const totalContributions = allDays.reduce((sum, day) => sum + day.count, 0)
  const last7Days = allDays.slice(-7)
  const last7DaysCount = last7Days.reduce((sum, day) => sum + day.count, 0)
  const last30Days = allDays.slice(-30)
  const last30DaysCount = last30Days.reduce((sum, day) => sum + day.count, 0)
  const activeDays = allDays.filter(day => day.count > 0).length

  return (
    <VStack
      padding={13}
      spacing={8}
      frame={displaySize}
      background={theme.background as any}
    >
      <HStack>
        <Text font="caption2" foregroundStyle={theme.text as any}>@{data.username}</Text>
        <Text font="caption2" foregroundStyle={theme.subtext as any}>140天 GitHub 贡献热力图</Text>
      </HStack>

      <HeatmapGrid weeks={recentWeeks} colorScheme={colorScheme} />

      <HStack spacing={0}>
        <VStack spacing={0} alignment="center" frame={{ maxWidth: Infinity }}>
          <Text font="caption2" foregroundStyle={theme.subtext as any}>总贡献</Text>
          <Text font="footnote" fontWeight="semibold" foregroundStyle={theme.text as any}>{totalContributions}</Text>
        </VStack>
        <VStack spacing={0} alignment="center" frame={{ maxWidth: Infinity }}>
          <Text font="caption2" foregroundStyle={theme.subtext as any}>近7天</Text>
          <Text font="footnote" fontWeight="semibold" foregroundStyle={theme.text as any}>{last7DaysCount}</Text>
        </VStack>
        <VStack spacing={0} alignment="center" frame={{ maxWidth: Infinity }}>
          <Text font="caption2" foregroundStyle={theme.subtext as any}>近30天</Text>
          <Text font="footnote" fontWeight="semibold" foregroundStyle={theme.text as any}>{last30DaysCount}</Text>
        </VStack>
        <VStack spacing={0} alignment="center" frame={{ maxWidth: Infinity }}>
          <Text font="caption2" foregroundStyle={theme.subtext as any}>活跃日</Text>
          <Text font="footnote" fontWeight="semibold" foregroundStyle={theme.text as any}>{activeDays}</Text>
        </VStack>
      </HStack>
    </VStack>
  )
}

function buildErrorView(
  title: string,
  message: string,
  colorScheme?: 'light' | 'dark'
) {
  const theme = getTheme(colorScheme)
  return (
    <VStack padding={12} spacing={6} background={theme.background as any}>
      <Text font="caption" fontWeight="semibold" foregroundStyle={theme.text as any}>
        {title}
      </Text>
      <Text font="caption2" foregroundStyle={theme.error as any}>
        {message}
      </Text>
    </VStack>
  )
}

async function loadWidget() {
  const config = getWidgetConfig()

  try {
    const data = await fetchGitHubContributions(config)
    Storage.set(STORAGE_KEYS.CONTRIBUTIONS_CACHE, data)

    Widget.present(
      <EnvironmentValuesReader keys={['colorScheme']}>
        {({ colorScheme }) => buildWidgetView(data, colorScheme as 'light' | 'dark' | undefined)}
      </EnvironmentValuesReader>,
      {
        reloadPolicy: {
          policy: 'after',
          date: new Date(Date.now() + 60 * 60 * 1000)
        }
      } as any
    )
  } catch (error) {
    const cachedData = loadCache()

    if (cachedData) {
      Widget.present(
        <EnvironmentValuesReader keys={['colorScheme']}>
          {({ colorScheme }) => buildWidgetView(cachedData, colorScheme as 'light' | 'dark' | undefined)}
        </EnvironmentValuesReader>,
        {
          reloadPolicy: {
            policy: 'after',
            date: new Date(Date.now() + 60 * 60 * 1000)
          }
        } as any
      )
      return
    }

    Widget.present(
      <EnvironmentValuesReader keys={['colorScheme']}>
        {({ colorScheme }) =>
          buildErrorView(
                      config.username || 'GitHub',
                      `加载失败: ${String(error)}`,
                      colorScheme as 'light' | 'dark' | undefined
                    )
        }
      </EnvironmentValuesReader>
    )
  }
}

loadWidget()